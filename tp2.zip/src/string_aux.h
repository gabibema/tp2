#ifndef STRING_AUX_H_
#define STRING_AUX_H_

/*
 * PRE: -
 * POS: Libera todos los substrings del vector
 *      Si la lista de strings no es NULL
 */
void liberar_substrings(char** lista_strings);


#endif // STRING_AUX_H_