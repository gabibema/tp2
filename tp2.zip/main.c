#include "src/hospital.h"
#include "src/simulador.h"
#include "src/struct.h"
#include "src/graficos.h"
#include "src/lista.h"
#include <stdbool.h>
#include <stdio.h>
#include <time.h> 
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define ERROR -1

typedef struct{
    simulador_t* simulador;
    bool animaciones;
    bool jugando;
}Juego;


char leer_comando(){
    char linea[100];
    char* leido;
    leido = fgets(linea, 100, stdin);
    if(!leido)
        return 0;
    while(*leido == ' ')
        leido++;
    return (char)tolower(*leido);
}

#define VER_ESTADISTICAS 'e'
#define ATENDER_ENTRENADOR 'p'
#define INFORMACION_POKEMON 'i'
#define ADIVINAR_NIVEL 'a'
#define AGREGAR_DIFICULTAD 'n'
#define SELECCIONAR_DIFICULTAD 'd'
#define INFORMACION_DIFICULTAD 'o'
#define FINALIZAR 'q'
#define VOLVER_ATRAS 'b'

void inicializar_juego(Juego* juego, hospital_t* hospital){
    juego->simulador = simulador_crear(hospital);
    juego->animaciones = true;
    juego->jugando = true;
}

//Loop o volver hacia
void agregar_espacios(char* string, int tamanio){
    if(!string) return;

    int espacios = tamanio - (int)strlen(string) - 1;
    for(int i = 0; i < espacios; i ++) strcat(string," ");

    strcat(string, "║");
}

#define MENSAJE 51
void mostrar_estadisticas(Juego* juego){
    EstadisticasSimulacion e;
    simulador_simular_evento(juego->simulador, ObtenerEstadisticas, &e);
    char mensaje[MENSAJE];

    char opcion;
    do{
        system("clear");
        printf("    ╔═══════════════════◓═════════════════════╗\n");
        printf("    ║                                         ║\n");
        sprintf(mensaje,"    ║   ➤ Cantidad de Eventos Simulados: %i", e.cantidad_eventos_simulados);
        agregar_espacios(mensaje, MENSAJE);
        printf("%s\n",mensaje);

        sprintf(mensaje,"    ║   ➤ Entrenadores Atendidos: %i", e.entrenadores_atendidos);
        printf("    ║                                         ║\n");
        agregar_espacios(mensaje, MENSAJE);
        printf("%s\n",mensaje);

        sprintf(mensaje,"    ║   ➤ Pokemones Atendidos: %i", e.pokemon_atendidos);
        printf("    ║                                         ║\n");
        agregar_espacios(mensaje, MENSAJE);
        printf("%s\n",mensaje);

        sprintf(mensaje,"    ║   ➤ Pokemones en Espera: %i", e.pokemon_en_espera);
        printf("    ║                                         ║\n");
        agregar_espacios(mensaje, MENSAJE);
        printf("%s\n",mensaje);
        
        sprintf(mensaje,"    ║   ➤ Pokemones en Espera: %i", e.pokemon_en_espera);
        printf("    ║                                         ║\n");
        agregar_espacios(mensaje, MENSAJE);
        printf("%s\n",mensaje);

        sprintf(mensaje,"    ║   ➤ Entrenadores Totales: %i", e.entrenadores_totales);
        printf("    ║                                         ║\n");
        agregar_espacios(mensaje, MENSAJE);
        printf("%s\n",mensaje);

        sprintf(mensaje,"    ║   ➤ Pokemones Totales: %i", e.pokemon_totales);
        printf("    ║                                         ║\n");
        agregar_espacios(mensaje, MENSAJE);
        printf("%s\n",mensaje);

        sprintf(mensaje,"    ║   ➤ Cantidad de Puntos: %i", e.puntos);
        printf("    ║                                         ║\n");
        agregar_espacios(mensaje, MENSAJE);
        printf("%s\n",mensaje);
        printf("    ║                                         ║\n");
        printf("    ╚═══════════════════◓═════════════════════╝\n");
        printf("     [ Para Volver al Menu Ingresa (B) ]\n");
        printf(" ➤ ");
        opcion = leer_comando();
    } while(opcion != VOLVER_ATRAS);

}


bool mostrar_pokemones(void* poke, void* cont){
    pokemon_t* pokemon = poke;
    int* contador = cont;

    char string[51];
    sprintf(string, " ║   Pokemon N°%i : %s", *contador, pokemon->nombre);
    agregar_espacios(string, 51);
    printf("%s\n", string);
    printf(" ║                                             ║\n");

    (*contador)++;
    return true;
}

void mostrar_entrenador_nombre(char* nombre){
    char string[50];
    sprintf(string, " ║   Entrenador: %s", nombre);
    agregar_espacios(string, 50);
    printf("%s\n", string);
    printf(" ║                                             ║\n");   

}

void mostrar_entrenador(Juego* juego){
    entrenador_t* entrenador = lista_iterador_elemento_actual(juego->simulador->iterador_entrenadores);
    if(!entrenador){
        printf(" [ No hay más entrenadores para atender ]\n");
        sleep(2);
        return;
    }
    
    if (simulador_simular_evento(juego->simulador, AtenderProximoEntrenador, NULL) == ErrorSimulacion) return;

    char opcion;
    int contador = 1;
    do{
        system("clear");
        contador = 1;
        printf(" ╔═══════════════════◓═════════════════════════╗\n");
        printf(" ║                                             ║\n");
        mostrar_entrenador_nombre(entrenador->nombre);
        abb_con_cada_elemento(entrenador->pokemones,INORDEN, mostrar_pokemones, &contador);
        printf(" ╚═══════════════════◓═════════════════════════╝\n");
        printf("     [ Para Volver al Menu Ingresa (B) ]\n");
        printf(" ➤ ");
        opcion = leer_comando();
    } while(opcion != VOLVER_ATRAS);
}

void mostrar_pokemon(Juego* juego){
    if(!juego) return;

    InformacionPokemon info;
    char mensaje[50];

    if (simulador_simular_evento(juego->simulador, ObtenerInformacionPokemonEnTratamiento, &info) == ErrorSimulacion) return;
    if(!info.nombre_pokemon || !info.nombre_entrenador) return;

    char opcion;
    do{
        system("clear");
        printf(" ╔═══════════════════◓═════════════════════════╗\n");
        printf(" ║                                             ║\n");
        mostrar_entrenador_nombre((char*)info.nombre_entrenador);
        sprintf(mensaje, " ║   Pokemon: %s", info.nombre_pokemon);
        agregar_espacios(mensaje, 50);
        printf("%s\n", mensaje);
        printf(" ║                                             ║\n");   
        printf(" ╚═══════════════════◓═════════════════════════╝\n");
        printf("     [ Para Volver al Menu Ingresa (B) ]\n");
        printf(" ➤ ");
        opcion = leer_comando();
    } while(opcion != VOLVER_ATRAS);
}

void intentar_adivinar(Juego* juego){

}

void aniadir_dificultad(Juego* juego){

}

void cambiar_dificultad(Juego* juego){

}

void mostrar_dificultad(Juego* juego){

}

void finalizar_juego(Juego* juego){

}

void ejecutar_comando(Juego *juego, char comando){
    switch (comando) {
        case VER_ESTADISTICAS:
            mostrar_estadisticas(juego);
            break;
        case ATENDER_ENTRENADOR:
            mostrar_entrenador(juego);
            break;
        case INFORMACION_POKEMON: 
            mostrar_pokemon(juego);
            break;
        case ADIVINAR_NIVEL:
            intentar_adivinar(juego);
            break;
        case AGREGAR_DIFICULTAD:
            aniadir_dificultad(juego);
            break;
        case SELECCIONAR_DIFICULTAD:
            cambiar_dificultad(juego);
            break;
        case INFORMACION_DIFICULTAD:
            mostrar_dificultad(juego);
            break;
        case FINALIZAR:
            finalizar_juego(juego);
            break;
        default:
            printf(" [ La Opción Ingresada no es Válida ]\n");
            sleep(2);
            break;

    }
}

void destruir_juego(Juego* juego){
    simulador_destruir(juego->simulador);
}

// #define BLKB "\033[40m"
// #define REDB "\033[41m"
// #define GRNB "\033[42m"
// #define YELB "\033[43m"
// #define BLUB "\033[44m"
// #define MAGB "\033[45m"
// #define CYNB "\033[46m"
// #define WHTB "\033[47m"

void pantalla_carga(const char* color, int pokemon, int n_color){
    if(pokemon == 0){
        printf("%s\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠄⠀⠒⠒⠒⠂⠄⠀⠀⠀⠀⠀⢀⠠⠤⠀⠤⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣐⣊⣀⣀⣀⣀⠀⠀⠀⣀⠤⢄⠪⠖⠁⢰⡔⠡⠠⡄⠀⠀⠀⠀⠀⠁⠢⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡠⠐⠀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠉⠐⢪⠑⠁⠑⠊⠁⠀⠑⠂⠐⡰⠂⠀⠀⠀⠀⠀⠀⠀⠁⠐⠀⠄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡠⠂⠀⠀⠀⠀⠀⠀⠠⠠⠐⠈⠁⠀⠀⠀⠀⠀⠀⠀⠁⠀⠀⠀⠀⠠⠒⠊⠉⠉⠉⠉⠁⠐⠂⠄⠀⣀⠀⠀⠀⠀⠀⠐⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⠁⠀⠀⠀⠠⠠⠒⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⣾⣾⣶⣤⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠁⠂⢄⠀⠀⠀⠀⠀⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡇⢀⠀⠊⡠⠊⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢴⣿⣿⣿⣿⣿⣿⣿⣿⡗⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠁⠢⡤⠀⠀⠐⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠓⠀⠀⡔⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣷⡀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢂⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠆⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠂⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠁⠂⠃⢀⠀⢀⣥⣤⣤⣾⣾⠉⠀⠉⠉⠉⠏⣿⣿⣿⣿⣥⣄⣤⠄⡁⠀⠀⢀⡀⠀⡀⠄⠐⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⡀⠀⠀⠠⢄⠰⣀⡤⢰⡖⠐⣴⣤⣼⣿⣿⣿⣿⣿⣿⣦⡞⢣⡞⢓⣿⣿⣿⣿⣧⣿⣿⣿⣿⣦⣧⣤⣾⣆⡁⣤⡀⠠⣄⡀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⢀⠸⠄⠀⠁⠉⠂⠀⣉⣽⣦⣾⣿⣾⣿⣿⣿⣿⣿⣿⣿⣿⡿⣿⣿⣶⣶⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡂⠀⠽⠓⠀⡦⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⢀⠔⠂⠀⠐⠀⠀⠀⠀⠆⠛⢛⣛⣿⣧⣯⣏⣉⠙⠛⠛⠛⠿⠿⣁⡠⠔⠂⠉⠛⠉⢸⠿⠆⠘⠁⣀⡀⠙⢟⠛⠋⠛⠛⠉⣩⣏⣇⣥⣿⣿⡿⡍⠘⠃⠶⠠⠞⠋⠄⠄⡀⠀⠀⠀⠀⠀\n\
⠀⠀⢀⠀⠔⠈⠁⠀⠀⠀⢰⠂⠀⠀⠈⢸⠿⣿⣿⣿⣿⣶⣄⠀⠀⠀⠘⣉⣠⣤⠔⠀⠀⠀⣘⠀⠀⠀⠀⠀⠙⠣⡞⠀⠀⢀⣰⡿⣟⡨⢡⣿⡇⠩⠃⠀⠀⠈⢢⡀⠀⠀⠀⢀⣀⠁⠐⠂⡀⠀\n\
⠀⠀⠁⢀⡀⠀⡠⠆⠀⠠⠱⠀⢀⠀⢠⣿⠀⢛⣿⣿⣧⣂⡹⠛⠆⠀⠈⠙⡋⠀⣀⢤⠆⠀⠀⠀⠀⠀⢦⡀⢦⡴⠀⠀⠀⠙⠋⢤⢢⣿⣿⣿⣉⣀⣳⣆⠀⣦⡀⠱⢆⠀⠠⡄⠈⠋⠆⠊⠀⠀\n\
⠀⠀⠀⠨⠀⠀⠊⠀⠠⠂⡧⣤⣾⣶⣾⣿⣿⣿⣿⣿⠋⠀⠀⢀⠀⠀⠀⠀⠘⠃⡟⢁⡠⠀⠀⠀⠀⡄⣀⡏⠉⠀⠀⠤⠄⡀⠀⠀⠈⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⡖⠁⠁⠤⠵⠅⠀⠂⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⣥⣿⡿⢿⣿⠏⠁⢈⠍⠀⠀⠀⠐⠅⡀⠀⠀⠀⠀⠀⠀⠸⡁⠀⠼⠄⡀⠘⠁⠀⢀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠹⣿⣿⢿⠛⢿⣿⣏⣀⠈⠑⡄⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠐⠘⠛⠃⠉⣼⠃⠀⢀⠆⠀⠀⠀⠀⠀⠀⠈⢀⠦⡀⠀⠀⠀⠀⠈⠙⠃⠈⠀⠀⠀⠀⢠⣀⠂⠣⠄⠀⠃⠀⠀⠀⠀⠘⢀⠀⠀⠈⣿⣿⣤⣤⣤⡱⡄⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⢸⣶⣶⠿⠿⣟⠀⠀⠈⣄⠀⠀⠀⠀⠀⠁⠄⠀⠐⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠁⠂⠐⠀⠀⠀⣠⠀⠀⣠⠃⠀⠀⠀⣿⢛⣋⣉⣁⣀⡧⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⢓⣤⣞⠀⣄⡿⠀⠀⠀⠐⢀⠀⠀⡒⢰⠄⠤⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⢀⡀⢤⣤⣆⢐⠒⠉⡀⣀⡴⠏⠀⠀⠀⠠⣿⠟⠋⠉⣉⣾⡇⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠻⣿⣿⣿⣷⠀⠀⠀⠀⠀⠉⠃⠗⣄⠘⣾⣟⠀⠀⠉⠉⠐⠄⣤⠀⠀⠀⣄⠤⠊⠈⠀⠀⠀⢹⣿⠊⣠⡿⠘⠁⠀⠀⠀⠀⠀⠰⣿⣀⣤⣼⣿⠿⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⣿⣿⣿⣦⠀⠀⠀⠀⠀⠀⠀⠐⢄⠸⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⡾⠟⡰⠂⠀⠀⠀⠀⠀⠀⠀⢠⡴⣿⣿⣿⣿⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠊⣻⣿⡿⢿⣧⠀⠁⠀⠀⠀⢀⣀⣎⠳⢄⡙⠏⡆⢂⡀⣀⣀⣀⣀⢀⣀⣀⡀⡐⢄⡹⠃⣠⢾⣴⡶⠾⠷⠓⠂⠐⠞⣀⣨⡼⣿⣿⣿⠫⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠁⠈⠉⠱⣒⠂⠀⠐⢙⠋⠀⠀⠀⣹⡆⠠⡙⠉⠿⠿⠿⠏⠽⠿⠿⠿⠗⢊⣤⡚⠁⡀⢼⠿⠚⠛⠛⠁⠀⢀⣀⠜⠁⠘⠉⠀⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢻⣷⣵⣽⣶⣾⣷⡿⡿⠁⠀⠀⠈⠉⠉⠉⠀⠀⠀⠈⠉⠉⢠⣟⡿⠛⠀⠁⠀⠰⣶⣾⣿⡿⣫⠟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠛⢛⠙⡿⠿⠁⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣨⣁⣀⣦⣶⡿⣿⣿⣉⣁⡤⠔⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢾⣿⠝⠉⢿⣿⣗⠋⠻⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠊⠉⠉⠢⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n", color);
    } else if (pokemon == 1){
        printf("%s\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠤⠰⠃⠀⠀⠀⠀⠀⠀⠈⠀⠀⠊⠀⠀⠀⠂⢐⡲⡆⣄⢄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠃⣈⠘⠁⠢⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠀⠀⢁⣀⣤⣶⣷⣷⣦⡀⠀⠀⠀⠀⠀⠀⠀⠐⠤⠔⠓⠫⠕⠦⣄⡀⠈⠐⢬⡀⢱⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⠀⣰⣶⣶⣄⡀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠂⠀⠀⣠⣤⣾⣿⣿⣿⣿⣿⣿⣿⣇⠈⠄⠀⠀⠀⠀⠀⠀⢉⠂⠀⠀⠀⠀⠈⠙⠂⠬⣦⠀⠈⣀⣐⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠀⣸⣿⣿⣿⣿⣿⣤⡀⠂⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡄⠨⠀⠀⠀⠀⠀⠀⠀⠁⠒⠚⢏⠉⠀⠀⠀⠀⠈⠀⠀⡟⠛⠄⢀⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠀⣰⣿⣿⣿⣿⣿⣿⣿⣿⣦⡀⠁⠀⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⠀⢃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠑⡀⠐⠲⣤⣀⣤⠀⢣⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠂⢠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⣀⠀⠀⠀⠂⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠁⠆⠲⠾⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠄⠀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⣄⠀⠁⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⢀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠱⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠀⠀⠀⠀⠀⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡀⠑⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠆⠀⣰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⡀⠀⠀⠁⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⠀⠀⠀⠀⠀⠈⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡄⠠⡀⠀⠀⠀\n\
⠀⠀⠀⠐⠀⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣶⣄⡀⠈⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠁⠀⠀⠀⠀⠀⠀⢀⠄⠀⠀⠀⠀⣰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡀⢁⠀⠀⠀\n\
⠀⠀⢀⠂⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣤⡀⠀⠀⠀⠀⠀⠀⡇⠀⠀⠀⠀⠀⢀⠀⠀⠀⠀⠀⠂⠀⣀⣤⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡀⠣⠀⠀\n\
⠀⠀⠂⣰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⡄⠁⠀⠑⡀⠃⠀⠀⠀⠀⠀⠈⠀⠔⠀⠀⠀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⠀⠄⠀\n\
⠀⠰⢀⣿⣿⣿⣿⣿⣿⣿⣿⠿⠿⠛⠋⠉⠙⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠧⣀⡠⠊⠀⠀⠀⠀⠀⠛⠂⠀⠑⣄⠤⠼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇⠈⠀\n\
⠀⠃⣼⣿⣿⣿⣿⡿⠟⠋⠁⠀⠀⠀⠀⠀⠀⠀⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠿⠿⠿⠿⠿⠛⢫⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠛⠻⠿⠻⠿⠿⠿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠁⠀⠀⠀⠉⠛⠿⣿⣿⣿⣿⣿⣿⣿⣿⡄⢁\n\
⢀⢰⣿⣿⣿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠻⣿⣿⣿⣿⣿⣿⣿⠿⠿⣿⠋⠀⠀⢀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⣀⡀⠀⠀⠀⠀⠀⠀⠈⠙⢿⣿⣿⣿⡿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠿⣿⣿⣿⣿⣿⠀⠀\n\
⡀⢸⣿⡿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⣿⣿⡿⠟⠁⠀⠀⠀⠁⠀⠀⠀⣸⣿⣿⡿⣿⣿⡿⠙⠂⠀⠀⠀⠀⠀⠀⣀⠀⠀⣀⠀⠀⠀⠀⢻⣿⡿⠿⣿⣷⣷⡀⠀⠀⠀⠘⠿⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣿⣿⣿⡀⢀\n\
⡇⣼⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠻⠟⠁⠀⣀⠄⠀⠀⠀⠀⠀⣸⣿⠛⠉⠀⠈⠏⠀⠀⠀⠀⠀⠀⡠⠂⠉⠀⠀⠀⠀⠈⠀⠢⠀⠀⡏⠀⠀⠈⠻⣿⡟⠢⡀⠀⠀⠀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⣿⠇⡘\n\
⠇⡿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⠀⠀⠀⠀⡜⠿⠁⠀⠀⠀⡐⠀⠀⠀⠀⠀⢀⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢄⠘⠀⠀⠀⠀⠈⠀⠀⠱⡀⠀⠀⠀⠀⡀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⣿⠀⠀\n\
⠀⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢄⢀⢲⠂⠀⡀⠀⠀⠁⠀⠀⠀⠀⢀⠀⠀⠀⠀⠀⠠⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢡⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠂⠂⡀⢡⠈⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⡏⡘⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠁⢃⢀⡊⠀⢀⠀⠀⠀⠀⠀⠀⡆⠀⠀⠀⠀⠠⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⠀⠀⠀⠀⠀⠀⠀⠑⠐⠄⠐⠓⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠁⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠂⠐⠒⢁⠀⠀⠀⠀⠂⠀⠀⠀⠀⠀⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠰⡗⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠰⠂⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡉⠈⠀⠀⠀⠀⠀⠀⠀⢉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠃⠀⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠊⠀⠉⠁⠚⠓⠒⠂⠉⢈⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⠀⠀⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡱⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠊⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⠁⠀⠀⠀⠀⠀⠀⠀⠠⠀⠀⠀⠀⠀⢀⠀⠐⡠⠊⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡘⠀⠀⠀⠀⠀⠀⠀⠄⠀⠀⠀⡶⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡔⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⠀⠀⠈⣀⡠⠊⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⡀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣰⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⢖⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡀⢔⠙⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣈⠠⠤⠔⢊⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢗⠒⠂⠐⠒⠂⠛⠈⠁⢨⡇⠀⠀⠀⠀⠀⠀⠀⣀⠔⠁⠀⠈⠐⠂⠒⡀⠄⠀⠀⠒⠤⢂⠁⠀⠀⠉⠒⢄⣀⡀⠀⠀⠀⠀⠀⢠⠎⢀⠠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠑⠀⠀⠀⠀⠀⠀⢀⢀⢃⣤⣄⣀⡀⠀⠢⡎⠁⠒⠒⠂⠀⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⢩⠎⠈⠁⠀⢀⣠⣤⡔⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠉⠀⢁⡀⠀⠁⠀⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠱⣀⠀⠀⠀⠀⠀⠀⠀⠀⣈⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠃⠘⡠⠉⠡⠀⠉⢑⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠁⠂⠄⠄⣠⠂⠢⠄⠐⡀⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠂⠂⢠⠀⠂⠀⠐⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠐⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n", color);
    } else {
        printf("%s\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⠀⠀⠐⠈⠹⠶⠊⠉⠐⠠⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢐⠠⣯⣄⡀⠀⠀⠀⠀⠀⣤⡤⠀⣀⢀⠀⢰⣬⠀⠀⠤⠄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠄⢹⣿⡿⠀⠀⠀⠀⣖⡷⠄⠀⠉⠁⠀⠀⠀⣀⡀⠀⠀⠈⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⡀⠟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⣉⣁⡀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡄⠀⠀⠀⠀⠀⢠⡆⠀⠀⠀⠀⠀⢀⠀⠰⠀⠁⠀⠀⠘⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣁⣀⣀⣀⠀⠃⠀⠀⠛⠁⠀⠈⠛⠈⠀⠀⠀⠀⠀⠀⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠤⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠀⠠⠄⠀⠒⠒⠒⠀⠀⠤⢀⠉⠀⠂⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⢀⠀⠀⠀⠀⠀⠁⡀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡀⢨⡑⢤⣤⣈⠀⡄⠀⠀⠀⠀⠀⠐⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠘⠀⠀⠀⠀⠀⠀⠀⢀⡀⠶⢶⣶⣤⡐⢠⡄⠀⠀⢠⡄⢀⡀⠀⠀⡀⢤⠐⠆⠛⠈⠁⠀⠀⣾⣿⣿⣷⣄⠀⢄⠀⠀⠀⠀⠀⠀⠀⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠖⠈⠀⣰⠛⠛⠀⠁⠀⠀⠀⠀⠀⠀⠀⠙⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⣿⣧⡀⡀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣆⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⢄⢀⡚⠁⠀⣠⠞⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡰⠆⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⣿⣿⠉⠀⠙⠻⠗⠅⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣿⠀⣠⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡿⠐⠀⠀⠀⣀⠀⠀⠀⣀⢠⣿⣿⡟⠀⠀⠀⠀⠀⢃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠛⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⡿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣤⣀⣀⠀⠀⠀⠀⠀⠀⣸⣿⣿⠃⠐⠧⠀⠀⠂⠛⠠⡀⠀⠀⣀⠀⢤⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣿⣿⡿⠁⣠⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⢠⣶⣿⣿⣿⣿⣿⣷⣶⣶⣶⣶⣴⣿⣿⣟⣀⡤⠄⠒⠁⠀⠀⢠⠃⠀⠀⠀⠀⠠⠈⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⠔⣰⢿⣟⠁⠀⠀⠀⠀⠀⠀⠀⢴⣦⠀⠀⣀⣴⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠢⡀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⢘⣠⣿⣟⠀⡀⢰⡦⠀⠒⠀⢀⣤⣈⣴⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⢀⠀⠀⠀⠀⠀⢠⠁⠀⠀⠀⠀⢹⠂⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⡌⢿⣿⣿⣿⣿⣶⣶⣤⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⠀⠀⠀⠀⢸⠀⠀⠀⠀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠈⠠⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠉⢀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇⠀⠀⠀⢸⡀⣀⡤⠚⠁⠀⠀⠀⠀⠀⠀⣘⠀⠀⢰⡦⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇⠀⠀⠀⠀⢸⢋⠉⠀⠀⠀⠀⠀⠀⠀⠀⡰⠃⠀⠀⣸⠇⢀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠁⠀⠀⠐⠀⠀⡘⠈⠙⠐⠖⠀⠀⠀⠴⣞⣃⣀⢤⠐⠣⠁⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠀⠀⠀⠀⠀⢀⣔⠃⠀⠀⠀⠀⢰⠀⠀⠀⠀⠀⠈⠈⠀⠀⠀⠁⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⢀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠁⠀⠀⠀⠀⠀⡌⠀⠈⠄⠀⠀⠀⠀⠀⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠠⠂⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠁⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠘⠀⠀⠀⠀⠀⢠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠐⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⠁⠀⠀⠀⠀⠀⠀⠀⡠⠠⡅⠘⠐⢾⠇⠀⠀⠀⠀⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⡀⠀⠀⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⠀⠀⠀⠀⠀⠀⠀⢀⠄⠀⠀⠀⠈⠄⠀⠀⠑⢄⠀⠀⠀⠘⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⢀⠀⠀⠀⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠋⠀⠀⠀⠀⠀⠀⠀⢀⠴⠁⠀⠀⠀⠀⠀⠀⢂⠀⠀⠐⣦⡐⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⢸⠀⠀⠀⠀⠙⣿⣿⣿⡿⠿⠿⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠆⠀⠀⠘⡁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⢸⠀⠀⠀⣠⠀⠈⠉⠀⠀⠀⠀⠀⠀⠉⠛⢿⣿⣿⣿⣿⠿⠛⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⠀⠀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠘⣄⠀⣶⣷⠆⠀⠀⡀⠤⠄⠤⠄⣀⠀⠀⠀⠈⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡇⠀⠀⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⢿⣦⡿⣿⣿⠆⠀⠀⠀⠀⠀⠀⣸⣷⣦⣄⡀⠀⠀⠀⠀⢀⠀⠀⣄⠀⣤⣤⡀⣤⣾⣿⣿⣿⣿⣆⠀⣀⣀⣀⣀⠀⠀⠀⠀⠀⣇⣀⣠⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠚⠁⠀⡹⠃⠀⠀⠀⠀⠀⢀⣼⣿⣿⣿⣿⣿⡇⠒⠂⠁⠀⠀⠀⠀⠀⠀⠀⠀⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⣤⣾⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⢀⠎⠀⠀⠀⠀⠀⢀⣴⣿⣿⣿⣿⣿⣿⡟⠀⠀⠀⠀⠀⣀⠀⠠⠄⠐⠀⠀⠀⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠅⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠈⠁⠀⠀⠀⠀⣠⣴⡿⠋⠉⠀⠛⢿⣿⠏⠉⠉⠉⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡓⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠀⠀⠀⠀⢀⣴⠞⠋⠁⠀⠀⠀⣀⠴⠊⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠄⠉⠀⠀⠉⠛⢿⣿⣿⣿⣿⣿⣿⣿⠏⠀⠑⠀⠀⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\
⠀⠀⠀⠣⠴⠶⠻⠿⠀⠠⠤⠄⠐⠂⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠆⣀⣀⣀⠀⠠⠤⠚⠛⠛⠉⠉⠉⠉⠀⠈⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n", color);

    }

    //printf("Color: %i", n_color);
}


#define VER_ESTADISTICAS 'e'
#define ATENDER_ENTRENADOR 'p'
#define INFORMACION_POKEMON 'i'
#define ADIVINAR_NIVEL 'a'
#define AGREGAR_DIFICULTAD 'n'
#define SELECCIONAR_DIFICULTAD 'd'
#define INFORMACION_DIFICULTAD 'o'
#define FINALIZAR 'q'

void mostrar_opciones(){
printf("\
    ╔═══════════════════◓══════════════════╗\n\
    ║                                      ║  \n\
    ║   ➤ Ver Estadísticas (E)             ║\n\
    ║                                      ║\n\
    ║   ➤ Atender Entrenador (P)           ║\n\
    ║                                      ║\n\
    ║   ➤ Información Pokémon (I)          ║\n\
    ║                                      ║\n\
    ║   ➤ Adivinar Nivel (A)               ║\n\
    ║                                      ║\n\
    ║   ➤ Agregar Dificultad (N)           ║\n\
    ║                                      ║\n\
    ║   ➤ Seleccionar Dificultad (D)       ║\n\
    ║                                      ║\n\
    ║   ➤ Información Dificultad (O)       ║\n\
    ║                                      ║\n\
    ║   ➤ Finalizar (Q)                    ║\n\
    ║                                      ║\n\
    ╚═══════════════════◓══════════════════╝\n\
");
}

int main(int argc, char *argv[]) {
    srand ((unsigned)time(NULL));

    /*
    char colores[6][20];
    strcpy(colores[0], RED);
    strcpy(colores[1], GRN);
    strcpy(colores[2], YEL);
    strcpy(colores[3], BBLU);
    strcpy(colores[4], MAG);
    strcpy(colores[5], CYN);
    // char pokemones[3][1000] = {{CHARIZARD}, {BLASTOISE}, {VENUSAUR}};
    // char colores [7][1000] = {{RED},{GRN}, {YEL}, {BLU}, {MAG}, {CYN}, {WHT}};

    int poke = rand() % 3;
    int color = rand() % 6;

    //pantalla_carga(colores[color], poke, color);
    */
    hospital_t* hospital = hospital_crear();
    bool error = hospital_leer_archivo(hospital, "ejemplos/varios_entrenadores.hospital");

    int i = 0;
    if(argc > 1){
        while(i < argc && !error)
        error = hospital_leer_archivo(hospital, argv[i]);
    }

    if(!error) return ERROR;

    Juego juego;
    //bool animaciones = false;

    inicializar_juego(&juego, hospital);
    if(!juego.simulador) return ERROR;

    do{
        system("clear");
        mostrar_opciones();
        printf(" ➤ ");
        char c = leer_comando();
        system("clear");
        ejecutar_comando(&juego, c);
    }while(juego.jugando);


//sleep(4);
// destruir_juego(&juego);

    return 0;
}
